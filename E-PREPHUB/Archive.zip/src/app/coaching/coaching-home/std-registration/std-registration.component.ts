import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-std-registration',
  templateUrl: './std-registration.component.html',
  styleUrls: ['./std-registration.component.scss']
})
export class StdRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
